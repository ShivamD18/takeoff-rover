# TakeOFF Rover — Handoff (updated 2026-11-26)
Team "The Big 6ixers" (TMU EE). Wiring + embedded for a university competition rover.

**How to use this:** Start a new Claude chat, attach this zip (plus `TakeOffRover.zip` if you have it), and say:
"Read HANDOFF.md and continue the bring-up from Current status."

---

## What's in this zip
| File | What it is |
|---|---|
| `HANDOFF.md` | This summary |
| `ServoBenchTest/ServoBenchTest.ino` | Servo bench test (rebuilt 2026-11-26, **not yet compiled**) |

**Not included, still needed:** `TakeOffRover.zip`, the full firmware (config.h, pwm.h, drive.h, arm_ctrl.h, arm_kinematics.h, TakeOffRover.ino). It compiled with Bluepad32 4.1.0 but hasn't run on hardware. Download it from the original Claude chat and add it. `takeoff-arm-live.html` (Web Serial arm controller) also only exists in that chat.

---

## Robot
- 4-wheel skid steer, parallel-link (MeArm-style) arm, rack-and-pinion claw
- **Rover Rally:** obstacle course, push LEGO blocks into buckets, park. No arm needed.
- **Hungry Hungry Robots:** grab blocks with the claw and drop them into safe zones with 1" walls. Blocks stored on the rover score +5 and can't be stolen.
- Block type unknown (LEGO or Duplo), so the claw supports both

## Hardware (kit only, no extra parts)
- ESP32: assumed classic ESP32-WROOM-32 DevKit (not confirmed)
- L298N: left motor pair on channel A, right pair on channel B
- 4 DC motors (model and stall current unknown)
- 2× MG996R (shoulder, elbow), 1× SG90 (claw)
- Breadboard for signals only, not power
- Xbox Wireless controller via Bluepad32

## Pins
| Function | GPIO |
|---|---|
| Shoulder servo | 18 |
| Elbow servo | 19 |
| Claw servo | 21 |
| ENA / IN1 / IN2 | 25 / 26 / 27 |
| ENB / IN3 / IN4 | 33 / 32 / 13 |
| Battery sense (only if resistors are allowed) | 34 |

- Remove the ENA/ENB jumpers and add 10k pull-downs.
- Avoid GPIO 0, 1, 2, 3, 5, 6–11, 12, 14, 15.

## Power
- Servos run on their own 5.0 V regulator rail (6 V is above the SG90's rating).
- The ESP32 gets a separate 5 V supply. Common ground everywhere.
- Never power servos from the ESP32's 5V or 3V3 pins.
- Two MG996Rs can pull about 5 A at stall. The regulator rating is unknown.
- If the battery is above 12 V, pull the L298N 5V-EN jumper.
- While flashing over USB, disconnect the ESP32's external 5 V feed but keep ground connected.

## Arm geometry (Fusion CAD)
- Upper arm 120 mm, forearm 100 mm, shoulder pin 115 mm above ground, wrist to tool mount 40 mm
- Claw tip assumed 50 mm below the tool mount (to be measured)
- The crank parallelogram means the elbow servo sets the forearm's absolute angle. Level links keep the claw vertical.
- Safe range: θ1 −10°…100°, θ2 −85°…25°, fold angle θ1−θ2 between 20° and 160°
- Centring: 1500 µs should put θ1 at 45° and θ2 at −30°. Assumed 10 µs per degree, arm limits 850–2150 µs.
- Claw: 24T module 0.7 pinion (8.4 mm pitch radius) gives 0.293 mm of jaw gap per degree. Fully open is 45 mm; grip is block width minus 1.5 mm (LEGO 15.8, Duplo 31.7). Pads are rubber.
- Presets (claw tip x, z in mm): Pick (150, 8), Carry (130, 65), Drop over wall (190, 75), Stow (60, 70)

## Xbox controls
- Left stick drives; hold LB for 35% precision speed
- Right stick moves the claw
- A / B / Y / X = Pick / Carry / Drop / Stow
- RB = grip / open
- D-pad left/right = LEGO / Duplo

---

## Current status (2026-11-26)
- Everything is wired and the ESP32 is powered. Ready to flash.
- Earlier, the SG90 worked on the bench and the MG996R did not. **Unresolved:** whether that's fixed, whether one or both MG996Rs are affected, and the rail voltage under load.
- MG996R troubleshooting checklist: right command letter (s/e); servo power from the regulator, not USB; rail voltage while commanding; swap onto GPIO21 to rule out the pin; test the other MG996R; check whether it's a 360° continuous-rotation version.

## Bring-up plan (do it in order)
1. **Pre-power checks:** no short between battery + and GND; regulator reads 5.0 V unloaded; ENA/ENB jumpers off; common ground.
2. **Make it safe:** rover on a box with wheels off the ground; arm servo horns off or the arm held by hand.
3. **Arduino IDE:** add this to Boards Manager URLs:
   `https://raw.githubusercontent.com/ricardoquesada/esp32-arduino-lib-builder/master/bluepad32_files/package_esp32_bluepad32_index.json`
   Install **esp32_bluepad32 4.1.0**, then select **ESP32 Dev Module** under it. Hold BOOT if the upload hangs on "Connecting…".
4. **ServoBenchTest:** Serial Monitor at 115200, line ending Newline. Commands are `s|e|c <µs>`, `x` (all limp), `t` (toggle telemetry). Servos are limp at boot.
   - `c 1500` first (known-good SG90), then `s 1500` / `e 1500`. Measure the rail voltage on each.
   - Record: shoulder µs at 45°, −10°, 100°; elbow µs at −30°, −85°, 25°; claw µs fully open and fully closed. Rail sag below about 4.6 V means the regulator is too weak.
   - Reinstall the horns at the 45° / −30° positions.
5. **TakeOffRover firmware (still on the box):** controller pairing; failsafe (turn the controller off and the motors must stop); motor direction per side; minimum PWM where the wheels actually turn (the L298N drops about 2 V); presets one at a time.
6. **Floor test:** drive normally and with LB held, Pick → Carry → Drop cycles. Watch for ESP32 resets under motor load (a brownout).

## Open items
- Battery type, voltage, mAh; regulator model and current rating
- Motor model and stall current
- Exact ESP32 board
- Block type (LEGO or Duplo)
- Real claw tip length
- Each servo's measured pulse limits (step 4)
- Whether to add an on-board storage bin
