// ServoBenchTest.ino — TakeOFF Rover (The Big 6ixers)
// Serial @115200, line ending "Newline".
// Commands:
//   s <us>   shoulder (GPIO18)   e.g.  s 1500
//   e <us>   elbow    (GPIO19)
//   c <us>   claw     (GPIO21)
//   x        all servos limp (stop pulses)
//   t        toggle telemetry on/off
// Telemetry (20 Hz):  T <s_us> <e_us> <c_us> <loop_us> <ms>   (0 = limp)
// Servos are LIMP at boot until you command them.

#include <Arduino.h>

const int PIN_S = 18, PIN_E = 19, PIN_C = 21;
const int PWM_FREQ = 50;      // 20 ms frame
const int PWM_BITS = 14;      // 16384 counts per 20 ms
const int CH_S = 0, CH_E = 1, CH_C = 2;  // used only on core 2.x

// Limits: arm servos per design plan, claw wider for calibration
const int ARM_MIN = 850,  ARM_MAX = 2150;
const int CLAW_MIN = 500, CLAW_MAX = 2500;

int usS = 0, usE = 0, usC = 0;   // 0 = limp
bool telemetry = true;
uint32_t lastT = 0, loopStart = 0, loopUs = 0;
String line;

uint32_t usToDuty(int us) {
  return (uint32_t)((uint64_t)us * ((1UL << PWM_BITS) - 1) / 20000UL);
}

void pwmInit(int pin, int ch) {
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcAttach(pin, PWM_FREQ, PWM_BITS);
#else
  ledcSetup(ch, PWM_FREQ, PWM_BITS);
  ledcAttachPin(pin, ch);
#endif
}

void pwmWriteUs(int pin, int ch, int us) {
  uint32_t d = us ? usToDuty(us) : 0;   // 0 duty = no pulse = limp
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcWrite(pin, d);
#else
  ledcWrite(ch, d);
#endif
}

int clampReport(const char* name, int us, int lo, int hi) {
  if (us < lo || us > hi) {
    int c = constrain(us, lo, hi);
    Serial.printf("! %s %d out of range [%d..%d], clamped to %d\n", name, us, lo, hi, c);
    return c;
  }
  return us;
}

void handle(String cmd) {
  cmd.trim();
  if (cmd.length() == 0) return;
  char k = tolower(cmd.charAt(0));
  int us = cmd.substring(1).toInt();

  switch (k) {
    case 's':
      usS = clampReport("shoulder", us, ARM_MIN, ARM_MAX);
      pwmWriteUs(PIN_S, CH_S, usS);
      Serial.printf("> shoulder %d us\n", usS);
      break;
    case 'e':
      usE = clampReport("elbow", us, ARM_MIN, ARM_MAX);
      pwmWriteUs(PIN_E, CH_E, usE);
      Serial.printf("> elbow %d us\n", usE);
      break;
    case 'c':
      usC = clampReport("claw", us, CLAW_MIN, CLAW_MAX);
      pwmWriteUs(PIN_C, CH_C, usC);
      Serial.printf("> claw %d us\n", usC);
      break;
    case 'x':
      usS = usE = usC = 0;
      pwmWriteUs(PIN_S, CH_S, 0);
      pwmWriteUs(PIN_E, CH_E, 0);
      pwmWriteUs(PIN_C, CH_C, 0);
      Serial.println("> all limp");
      break;
    case 't':
      telemetry = !telemetry;
      Serial.printf("> telemetry %s\n", telemetry ? "on" : "off");
      break;
    default:
      Serial.println("? use: s|e|c <us>, x, t");
  }
}

void setup() {
  Serial.begin(115200);
  delay(300);
  pwmInit(PIN_S, CH_S);
  pwmInit(PIN_E, CH_E);
  pwmInit(PIN_C, CH_C);
  pwmWriteUs(PIN_S, CH_S, 0);
  pwmWriteUs(PIN_E, CH_E, 0);
  pwmWriteUs(PIN_C, CH_C, 0);
  Serial.println("\nServoBenchTest ready. Servos limp. Try: c 1500");
}

void loop() {
  loopStart = micros();

  while (Serial.available()) {
    char ch = Serial.read();
    if (ch == '\n' || ch == '\r') { handle(line); line = ""; }
    else if (line.length() < 32) line += ch;
  }

  uint32_t now = millis();
  if (telemetry && now - lastT >= 50) {
    lastT = now;
    Serial.printf("T %d %d %d %lu %lu\n", usS, usE, usC,
                  (unsigned long)loopUs, (unsigned long)now);
  }

  loopUs = micros() - loopStart;
}
