# TakeOFF Rover — The Big 6ixers (TMU EE)

Wiring and embedded work for a competition rover: 4-wheel skid-steer, a parallel-link (MeArm-style) arm, and a rack-and-pinion claw.

## What's in this package

| Path | What it is |
|---|---|
| `TakeOffRover/` | Full rover firmware (Arduino sketch folder). Xbox drive, arm inverse kinematics, presets, claw, failsafe, battery monitor. Compiles with Bluepad32 4.1.0; **not yet run on hardware**. |
| `ServoBenchTest/` | Servo bench test. Serial commands `s/e/c <µs>`; prints telemetry `T s e c loop_us ms` at 20 Hz. |
| `takeoff-arm-live.html` | Live link page. Open in **Chrome or Edge** on a laptop, upload ServoBenchTest, close Serial Monitor, click Connect: the virtual arm drives the real servos. |
| `takeoff-arm-sim.html` | Offline arm simulator (same math, no USB). Opens in any browser. |
| `SUMMARY.md` | This file. |

## Games

- **Rover Rally:** obstacle course, push LEGO blocks into buckets, then park. Arm not needed.
- **Hungry Hungry Robots:** grab blocks with the claw, drop them into safe zones with 1-inch walls. Blocks stored on the rover score +5 and can't be stolen.
- Block type still unknown (regular LEGO or Duplo), so the claw supports both.

## Hardware (kit only, no extra parts; battery and regulators are provided)

- ESP32: assumed classic ESP32-WROOM-32 DevKit (exact board not confirmed)
- L298N motor driver: left pair on channel A, right pair on channel B
- 4 DC motors + wheels (model and stall current unknown)
- 2× MG996R (shoulder, elbow), 1× SG90 (claw)
- Breadboard: signals only, not power
- Xbox Wireless controller via Bluepad32

## Pin plan

| Part | ESP32 pin |
|---|---|
| Shoulder MG996R signal | GPIO18 |
| Elbow MG996R signal | GPIO19 |
| Claw SG90 signal | GPIO21 |
| L298N ENA / IN1 / IN2 | GPIO25 / 26 / 27 (remove ENA jumper, 10k pull-down) |
| L298N ENB / IN3 / IN4 | GPIO33 / 32 / 13 (remove ENB jumper, 10k pull-down) |
| Battery sense (only if resistors allowed) | GPIO34 |
| Ground | Common GND everywhere |

Avoid: 0, 2, 5, 12, 15 (boot), 6–11 (flash), 1, 3 (USB serial), 14. Free: 4, 16, 17, 22, 23; inputs only 35, 36, 39.

## Power plan

- Servos on their own **5.0 V** regulator rail (6 V is over the SG90's rating).
- ESP32 on a separate 5 V supply (or USB while testing).
- Common ground. Never power servos from the ESP32's 5V or 3V3 pins.
- **Still needed:** battery type/voltage/mAh, regulator model and current rating. Two MG996Rs can pull ~5 A at stall.

## Arm geometry (from the Fusion CAD parameters)

- Upper arm 120 mm, forearm 100 mm, shoulder pin 115 mm above ground, wrist to tool mount 40 mm.
- Claw tip assumed 50 mm below the tool mount (**measure**).
- Crank parallelogram: the elbow servo sets the forearm's absolute angle. Level-keeping links keep the claw vertical.
- **Safe range:** upper arm θ1 −10°…100°, forearm θ2 −85°…25°, fold θ1 − θ2 between 20° and 160°.
- **Servo centring:** at 1500 µs, upper arm at 45°, forearm at −30°. Assumed 10 µs/°, arm limits 850–2150 µs.
- **Claw:** 24-tooth module 0.7 pinion (8.4 mm pitch radius) → 0.293 mm of gap per servo degree. Open 45 mm; grip = block width − 1.5 mm (LEGO 15.8 mm, Duplo 31.7 mm). Rubber pads.
- **Presets (claw tip x, z in mm):** Pick (150, 8), Carry (130, 65), Drop (190, 75), Stow (60, 70).

## Xbox controls

| Input | Action |
|---|---|
| Left stick | Drive (hold LB for 35 % precision speed) |
| Right stick | Move the claw tip |
| A / B / Y / X | Pick / Carry / Drop / Stow |
| RB | Grip / open |
| D-pad left / right | LEGO / Duplo |

## Setting up a new computer

1. Install Arduino IDE 2.
2. **File → Preferences → Additional Board Manager URLs:**
   `https://raw.githubusercontent.com/ricardoquesada/esp32-arduino-lib-builder/master/bluepad32_files/package_esp32_bluepad32_index.json`
3. **Boards Manager:** install **esp32_bluepad32**.
4. **Tools → Board:** ESP32 + Bluepad32 Arduino → **ESP32 Dev Module**. Pick the COM port (install the CP210x or CH340 driver if none shows).
5. Open `ServoBenchTest/ServoBenchTest.ino` for servo testing, or `TakeOffRover/TakeOffRover.ino` for the full rover. Hold **BOOT** if upload stalls at "Connecting…".
6. Serial Monitor: 115200 baud, line ending "Newline".

## Current status

- SG90 works on the bench. **MG996R not working.** Troubleshooting checklist:
  1. Right command letter (`s` = shoulder/GPIO18, `e` = elbow/GPIO19).
  2. Servo power from the regulator, not USB.
  3. Measure rail voltage while commanding it (should stay near 5 V; ESP32 resets = sagging supply).
  4. Swap the MG996R onto GPIO21 (`c` commands) to rule out the pin/wiring.
  5. Test the other MG996R.
  6. Check it isn't the 360° continuous-rotation version (spins instead of holding position).
- Waiting on: what the MG996R does (nothing / twitches / spins / ESP32 resets), one or both, rail voltage.

## Open items

- Battery and regulator specs
- Motor model and stall current
- Exact ESP32 board
- Block type (LEGO or Duplo)
- Real claw tip length (`TIP_BELOW_P` in `arm_kinematics.h`)
- Each servo's measured pulse limits (CAL values in `arm_kinematics.h`)
- Whether to add an on-board storage bin (+5 per block)
