// TakeOffRover.ino — The Big 6ixers, TakeOFF Rover firmware (ESP32 + Xbox Wireless controller).
//
// Build: Arduino IDE / arduino-cli with the "ESP32 + Bluepad32 Arduino" board package
//        (board: ESP32 Dev Module under esp32_bluepad32). Bluepad32 is bundled in that package.
//
// Controls (Xbox layout):
//   Left stick ........ drive (arcade: up/down = throttle, left/right = turn)
//   LB (hold) ......... precision drive (35 % speed) for checkpoint 3 and parking
//   Right stick ....... move claw tip: left/right = reach in/out, up/down = height
//   A / B / Y / X ..... presets: PICK / CARRY / DROP-over-wall / STOW
//   RB ................ claw grip <-> open
//   D-pad left/right .. block size LEGO / Duplo (1 or 2 rumbles to confirm)
//
// Safety: drive brakes and the arm/claw hold position whenever the controller is not
// connected. The physical kill switch is still the primary emergency stop.
#include <Bluepad32.h>
#include "config.h"
#include "drive.h"
#include "arm_ctrl.h"

Drive drive;
Arm arm_;
Claw claw_;
ControllerPtr pad = nullptr;

// ---------- Battery ----------
float vbat = 8.0f;
bool lowBatt = false, critBatt = false;

void updateBattery() {
  float v = analogReadMilliVolts(PIN_VBAT) / 1000.0f * VBAT_DIVIDER;
  vbat += 0.1f * (v - vbat);                                   // ~1 s filter at 10 Hz
  if (!critBatt && vbat < VBAT_CRIT) critBatt = true;
  if (critBatt && vbat > VBAT_CRIT + 0.2f) critBatt = false;   // hysteresis
  bool wasLow = lowBatt;
  if (!lowBatt && vbat < VBAT_LOW) lowBatt = true;
  if (lowBatt && vbat > VBAT_LOW + 0.2f) lowBatt = false;
  if (lowBatt && !wasLow && pad) pad->playDualRumble(0, 600, 0xC0, 0xC0);
}

// ---------- Controller connection ----------
void onConnected(ControllerPtr c) {
  if (pad != nullptr || !c->isGamepad()) { c->disconnect(); return; }  // one controller only
  pad = c;
  // Stop scanning so another team's controller can't pair mid-match. The bonded
  // controller can still reconnect.
  BP32.enableNewBluetoothConnections(false);
  c->playDualRumble(0, 250, 0x80, 0x40);
  Serial.printf("Controller connected: %s\n", c->getModelName().c_str());
}

void onDisconnected(ControllerPtr c) {
  if (c == pad) {
    pad = nullptr;
    drive.emergencyStop();
    arm_.hold();
    BP32.enableNewBluetoothConnections(true);   // allow re-pairing if keys were lost
    Serial.println("Controller lost: drive braked, arm holding");
  }
}

// ---------- Input shaping ----------
float stick(int32_t raw) {                       // Bluepad32 sticks: -511..512
  float v = constrain(raw / 512.0f, -1.0f, 1.0f);
  if (fabsf(v) < STICK_DEADBAND) return 0.0f;
  float s = (fabsf(v) - STICK_DEADBAND) / (1.0f - STICK_DEADBAND);
  s = (1.0f - EXPO) * s + EXPO * s * s * s;      // expo: fine control near centre
  return v < 0 ? -s : s;
}

struct Edge { bool prev = false; bool rose(bool now) { bool r = now && !prev; prev = now; return r; } };
Edge eA, eB, eX, eY, eRB, eLeft, eRight;

// ---------- Main ----------
void setup() {
  // Motors first: bridges must be off before anything else happens.
  drive.begin();
  Serial.begin(115200);
  analogReadResolution(12);
  analogSetPinAttenuation(PIN_VBAT, ADC_11db);
  arm_.begin();
  claw_.begin();
  BP32.setup(&onConnected, &onDisconnected);
  BP32.enableVirtualDevice(false);
  Serial.println("TakeOFF Rover ready - turn on the Xbox controller (hold pair button first time)");
}

void loop() {
  BP32.update();

  static uint32_t lastTick = 0, lastBatt = 0;
  uint32_t now = millis();
  if (now - lastBatt >= 100) { lastBatt = now; updateBattery(); }
  if (now - lastTick < 20) return;               // 50 Hz control loop, non-blocking
  float dt = (now - lastTick) / 1000.0f;
  lastTick = now;
  if (dt > 0.1f) dt = 0.1f;

  if (pad == nullptr || !pad->isConnected()) {   // failsafe
    drive.emergencyStop();
    arm_.hold();
    claw_.update(dt);                            // keep gripping whatever it holds
    return;
  }

  // Drive
  float throttle = -stick(pad->axisY());         // stick up = negative axisY
  float turn     =  stick(pad->axisX());
  float scale = pad->l1() ? PRECISION_SCALE : 1.0f;
  if (lowBatt) scale *= 0.5f;
  if (critBatt) drive.emergencyStop();
  else drive.command(throttle, turn, scale, dt);

  // Presets
  if (eA.rose(pad->a())) arm_.goTo(POSE_PICK);
  if (eB.rose(pad->b())) arm_.goTo(POSE_CARRY);
  if (eY.rose(pad->y())) arm_.goTo(POSE_DROP);
  if (eX.rose(pad->x())) arm_.goTo(POSE_STOW);

  // Claw
  if (eRB.rose(pad->r1())) claw_.toggle();
  uint8_t dp = pad->dpad();
  if (eLeft.rose(dp & DPAD_LEFT))  { claw_.setBlock(claw::Block::LEGO);  pad->playDualRumble(0, 120, 0x60, 0x00); }
  if (eRight.rose(dp & DPAD_RIGHT)) { claw_.setBlock(claw::Block::DUPLO); pad->playDualRumble(0, 400, 0x60, 0x00); }

  // Arm (manual trim) — frozen on critical battery to protect the servo rail
  float ax = stick(pad->axisRX());
  float az = -stick(pad->axisRY());
  if (critBatt) arm_.hold(); else arm_.update(ax, az, dt);
  claw_.update(dt);
}
