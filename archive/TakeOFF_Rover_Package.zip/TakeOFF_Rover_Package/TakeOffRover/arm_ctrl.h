// arm_ctrl.h — arm (2x MG996R) and claw (SG90) control.
// Manual trim moves the claw tip in straight lines (Cartesian). Presets move in joint space,
// which always stays inside the convex safe region (see arm_kinematics.h).
#pragma once
#include <Arduino.h>
#include "config.h"
#include "pwm.h"
#include "arm_kinematics.h"

class Arm {
public:
  void begin() {
    pwm::attach(PIN_SERVO_SHOULDER, CH_SHOULDER, SERVO_HZ, SERVO_BITS);
    pwm::attach(PIN_SERVO_ELBOW,    CH_ELBOW,    SERVO_HZ, SERVO_BITS);
    // Power on with the arm folded: the first pulse commands STOW.
    arm::solveIK(POSE_STOW.x, POSE_STOW.z, t1_, t2_);
    arm::forwardTip(t1_, t2_, x_, z_);
    write();
  }

  void goTo(const Pose &p) {
    float a, b;
    if (arm::solveIK(p.x, p.z, a, b)) { gt1_ = a; gt2_ = b; presetActive_ = true; }
  }

  // vx, vz in [-1, 1] from the right stick. Any stick input cancels a preset move.
  void update(float vx, float vz, float dt) {
    if (fabsf(vx) > 0.0f || fabsf(vz) > 0.0f) {
      presetActive_ = false;
      float nx = x_ + vx * ARM_TRIM_MM_S * dt;
      float nz = z_ + vz * ARM_TRIM_MM_S * dt;
      float a, b;
      if (arm::solveIK(nx, nz, a, b)) { x_ = nx; z_ = nz; t1_ = a; t2_ = b; }
      // Unreachable target: stay where we are (no jump).
    } else if (presetActive_) {
      float step = ARM_PRESET_DEG_S * dt;
      t1_ = approach(t1_, gt1_, step);
      t2_ = approach(t2_, gt2_, step);
      arm::forwardTip(t1_, t2_, x_, z_);
      if (t1_ == gt1_ && t2_ == gt2_) presetActive_ = false;
    }
    write();
  }

  void hold() { presetActive_ = false; write(); }   // keep pulses alive, stop moving

private:
  float t1_ = arm::T1_CENTRE, t2_ = arm::T2_CENTRE, gt1_ = 0, gt2_ = 0, x_ = 0, z_ = 0;
  bool presetActive_ = false;

  static float approach(float c, float t, float s) {
    if (fabsf(t - c) <= s) return t;
    return c + (t > c ? s : -s);
  }
  void write() {
    pwm::servoUs(PIN_SERVO_SHOULDER, CH_SHOULDER, arm::shoulderUs(t1_));
    pwm::servoUs(PIN_SERVO_ELBOW,    CH_ELBOW,    arm::elbowUs(t2_));
  }
};

class Claw {
public:
  void begin() {
    pwm::attach(PIN_SERVO_CLAW, CH_CLAW, SERVO_HZ, SERVO_BITS);
    gap_ = target_ = claw::OPEN_GAP;
    write();
  }
  void open()            { target_ = claw::OPEN_GAP; gripping_ = false; }
  void grip()            { target_ = claw::gapForGrip(block_, claw::SQUEEZE); gripping_ = true; gripSince_ = millis(); }
  void toggle()          { gripping_ ? open() : grip(); }
  void setBlock(claw::Block b) { block_ = b; if (gripping_) grip(); }
  claw::Block block() const { return block_; }

  void update(float dt) {
    // Long hold: back off the squeeze so the SG90 is not stalled hard indefinitely.
    if (gripping_ && millis() - gripSince_ > CLAW_RELIEF_MS)
      target_ = claw::gapForGrip(block_, claw::SQUEEZE_RELIEVED);
    float s = CLAW_MM_S * dt;
    if (fabsf(target_ - gap_) <= s) gap_ = target_;
    else gap_ += (target_ > gap_ ? s : -s);
    write();
  }

private:
  float gap_ = claw::OPEN_GAP, target_ = claw::OPEN_GAP;
  bool gripping_ = false;
  uint32_t gripSince_ = 0;
  claw::Block block_ = claw::Block::LEGO;
  // Pulses are never stopped: an SG90 without signal goes limp and drops the block.
  void write() { pwm::servoUs(PIN_SERVO_CLAW, CH_CLAW, claw::usForGap(gap_)); }
};
