// config.h — pin map and tunables. Must match the wiring table.
// Board: ESP32-WROOM-32 DevKit (classic ESP32, assumed). Pins avoid strapping pins
// 0/2/5/12/15, flash pins 6-11, UART 1/3 and GPIO14 (pulses at boot).
#pragma once
#include <stdint.h>

// ---------- L298N (left pair on A, right pair on B) ----------
constexpr uint8_t PIN_ENA = 25;  // left speed PWM   (10k pull-down to GND, ENA jumper removed)
constexpr uint8_t PIN_IN1 = 26;
constexpr uint8_t PIN_IN2 = 27;
constexpr uint8_t PIN_ENB = 33;  // right speed PWM  (10k pull-down to GND, ENB jumper removed)
constexpr uint8_t PIN_IN3 = 32;
constexpr uint8_t PIN_IN4 = 13;

// ---------- Servos (signal only; power from the 5 V servo buck) ----------
constexpr uint8_t PIN_SERVO_SHOULDER = 18;  // MG996R #1
constexpr uint8_t PIN_SERVO_ELBOW    = 19;  // MG996R #2 (crank)
constexpr uint8_t PIN_SERVO_CLAW     = 21;  // SG90

// ---------- Battery sense: 100k top / 33k bottom, 100 nF at the pin ----------
constexpr uint8_t PIN_VBAT = 34;            // ADC1, input-only, works while Bluetooth is on
constexpr float   VBAT_DIVIDER = (100.0f + 33.0f) / 33.0f;
constexpr float   VBAT_LOW  = 6.8f;         // 2S: ~3.4 V/cell -> half speed + rumble warning
constexpr float   VBAT_CRIT = 6.4f;         // 2S: ~3.2 V/cell -> drive and arm stop

// ---------- LEDC channels (core 2.x API) ----------
constexpr uint8_t CH_LEFT = 0, CH_RIGHT = 1;              // share timer 0
constexpr uint8_t CH_SHOULDER = 2, CH_ELBOW = 4, CH_CLAW = 6; // timers 1..3 (50 Hz)
constexpr uint32_t MOTOR_PWM_HZ   = 1000;  // L298 is a slow bipolar bridge: keep switching losses low
constexpr uint8_t  MOTOR_PWM_BITS = 10;    // 0..1023
constexpr uint32_t SERVO_HZ       = 50;
constexpr uint8_t  SERVO_BITS     = 16;    // 20 ms frame, ~0.3 us per step

// ---------- Drive feel ----------
constexpr bool  LEFT_INVERT  = false;      // flip if a side drives backwards
constexpr bool  RIGHT_INVERT = true;       // sides are mirrored on a skid-steer
constexpr float STICK_DEADBAND = 0.08f;
constexpr float EXPO          = 0.6f;      // 0 = linear, 1 = cubic
constexpr float TURN_GAIN     = 0.8f;
constexpr float PRECISION_SCALE = 0.35f;   // hold LB
constexpr float ACCEL_PER_S   = 3.3f;      // 0 -> full in ~0.3 s (wheelspin control on the ramp)
constexpr float DECEL_PER_S   = 6.0f;      // full -> 0 in ~0.17 s
constexpr float MIN_EFFECTIVE = 0.25f;     // CAL: smallest duty that actually turns the wheels

// ---------- Arm feel ----------
constexpr float ARM_TRIM_MM_S   = 120.0f;  // right stick Cartesian speed
constexpr float ARM_PRESET_DEG_S = 90.0f;  // joint speed for preset moves
constexpr float CLAW_MM_S       = 40.0f;   // jaw gap rate (slow close = seats without slamming)
constexpr uint32_t CLAW_RELIEF_MS = 20000; // reduce squeeze after a long hold

// ---------- Presets: claw tip (x forward of shoulder axis, z above ground), mm ----------
// All verified inside the arm's safe region on a PC. Tune on the real rover.
struct Pose { float x, z; };
constexpr Pose POSE_STOW  = { 60.0f, 70.0f};  // folded, low CG for ramps and drops
constexpr Pose POSE_PICK  = {150.0f,  8.0f};  // claw just above the floor
constexpr Pose POSE_CARRY = {130.0f, 65.0f};  // clears 1-inch walls and speed bumps
constexpr Pose POSE_DROP  = {190.0f, 75.0f};  // reach over a wall, then open

