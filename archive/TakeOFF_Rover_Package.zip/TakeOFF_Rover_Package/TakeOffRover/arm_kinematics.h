// arm_kinematics.h — TakeOFF Rover arm + claw geometry and inverse kinematics.
// Geometry from the Fusion user parameters in TakeOFF_Rover (v10, 2026-10-28).
// Values marked CAL must be measured on the built arm.
#pragma once
#include <math.h>
#include <stdint.h>

namespace arm {

// ---------- Geometry from CAD (mm) ----------
constexpr float A2          = 120.0f; // arm_a2: shoulder pin S -> elbow pin E
constexpr float A3          = 100.0f; // arm_a3: elbow pin E -> wrist pin W
constexpr float SHOULDER_H  = 115.0f; // arm_shoulder_h = deck 55 + turntable 60 (above ground)
constexpr float TOOL        = 40.0f;  // arm_tool: wrist pin W straight down to tool mount P
constexpr float TIP_BELOW_P = 50.0f;  // CAL: tool mount P down to the middle of the finger pads

// ---------- Working region (absolute angles from horizontal, CCW+, degrees) ----------
// CAD note: keep the upper arm >=30 deg from the 135 deg line and the forearm >=30 deg
// from the 60 deg line (both directions), or the level-keeping links jam. That leaves
//   upper arm  t1 in [-15, 105]   and   forearm  t2 in [-90, 30].
// 5 deg extra margin is kept below. These are also exactly +/-60 deg around the servo
// centre angles (t1 = 45, t2 = -30), so a 120-deg-travel MG996R covers the whole region.
constexpr float T1_MIN = -10.0f, T1_MAX = 100.0f;
constexpr float T2_MIN = -85.0f, T2_MAX = 25.0f;
constexpr float REL_MIN = 20.0f, REL_MAX = 160.0f;  // CAL: t1 - t2 (crank parallelogram must not go flat)
// The allowed set is an intersection of half-planes (convex), so a straight-line move
// between two allowed joint configurations never leaves it. Presets move in joint space.

constexpr float T1_CENTRE = 45.0f;    // upper arm angle when the shoulder servo gets 1500 us
constexpr float T2_CENTRE = -30.0f;   // forearm angle when the elbow servo gets 1500 us

struct ServoCal { float us0; float usPerDeg; float minUs; float maxUs; };
// CAL: fit the horns so 1500 us gives the centre angles above, then trim us0 and the sign.
constexpr ServoCal SHOULDER = {1500.0f, 10.0f, 850.0f, 2150.0f};
constexpr ServoCal ELBOW    = {1500.0f, 10.0f, 850.0f, 2150.0f};

inline bool anglesAllowed(float t1, float t2) {
  float rel = t1 - t2;
  return t1 >= T1_MIN && t1 <= T1_MAX && t2 >= T2_MIN && t2 <= T2_MAX &&
         rel >= REL_MIN && rel <= REL_MAX;
}

// Claw-tip target: x = forward distance from the shoulder axis, z = height above ground (mm).
// Returns absolute upper-arm (t1) and forearm (t2) angles; claw stays vertical.
inline bool solveIK(float x, float z, float &t1, float &t2) {
  float wx = x;
  float wz = z + TOOL + TIP_BELOW_P - SHOULDER_H;   // wrist pin relative to shoulder pin
  float d2 = wx * wx + wz * wz, d = sqrtf(d2);
  if (d > A2 + A3 - 2.0f || d < fabsf(A2 - A3) + 2.0f) return false;
  float c = (A2 * A2 + d2 - A3 * A3) / (2.0f * A2 * d);
  c = fmaxf(-1.0f, fminf(1.0f, c));
  float r1 = atan2f(wz, wx) + acosf(c);              // elbow-up branch
  float r2 = atan2f(wz - A2 * sinf(r1), wx - A2 * cosf(r1));
  t1 = r1 * 57.29578f;
  t2 = r2 * 57.29578f;
  return anglesAllowed(t1, t2);
}

inline void forwardTip(float t1, float t2, float &x, float &z) {
  float r1 = t1 / 57.29578f, r2 = t2 / 57.29578f;
  x = A2 * cosf(r1) + A3 * cosf(r2);
  z = SHOULDER_H + A2 * sinf(r1) + A3 * sinf(r2) - TOOL - TIP_BELOW_P;
}

inline uint16_t toUs(const ServoCal &c, float angleDeg) {
  float us = c.us0 + angleDeg * c.usPerDeg;
  return (uint16_t)fmaxf(c.minUs, fminf(c.maxUs, us));
}
inline uint16_t shoulderUs(float t1) { return toUs(SHOULDER, t1 - T1_CENTRE); }
// Elbow servo drives the 30 mm crank, which is parallel to the forearm tail, so
// crank angle = t2 + 180 and its offset from centre equals t2 - T2_CENTRE.
inline uint16_t elbowUs(float t2)    { return toUs(ELBOW, t2 - T2_CENTRE); }

} // namespace arm

namespace claw {
// Rack-and-pinion gripper from CAD: gripper_spur_gear = 24 teeth, module 0.7
// (tip dia 18.2 mm, root r 7.52 mm) -> pitch radius 8.4 mm; finger racks 2.2 mm pitch.
constexpr float PITCH_R     = 8.4f;                        // mm
constexpr float GAP_PER_DEG = 2.0f * PITCH_R * 0.0174533f; // 0.293 mm of opening per servo degree
constexpr float US_PER_DEG  = 10.0f;                       // CAL: SG90 pulse per degree
constexpr float REF_US      = 1500.0f;                     // CAL: pulse where the gap was measured
constexpr float REF_GAP     = 30.0f;                       // CAL: measured gap at REF_US (mm)
constexpr float OPEN_SIGN   = 1.0f;                        // CAL: +1 if a larger pulse opens the claw
constexpr float MIN_US = 700.0f, MAX_US = 2300.0f;         // CAL: ~3 deg inside the hard stops

// Block type not confirmed (standard LEGO vs Duplo): both supported, grab across the narrow side.
enum class Block : uint8_t { LEGO, DUPLO };
constexpr float LEGO_W   = 15.8f;  // standard LEGO 2xN brick width
constexpr float DUPLO_W  = 31.7f;  // Duplo 2xN brick width
constexpr float OPEN_GAP = 45.0f;  // fully open; lower it if the rails reach their stops first
constexpr float SQUEEZE  = 1.5f;   // mm past contact, taken up by the rubber pads
constexpr float SQUEEZE_RELIEVED = 0.8f; // after a long hold, to keep the SG90 cool

inline float gapForGrip(Block b, float squeeze) { return (b == Block::LEGO ? LEGO_W : DUPLO_W) - squeeze; }

inline uint16_t usForGap(float gapMm) {
  float us = REF_US + OPEN_SIGN * (gapMm - REF_GAP) / GAP_PER_DEG * US_PER_DEG;
  return (uint16_t)fmaxf(MIN_US, fminf(MAX_US, us));
}
} // namespace claw
