// ServoBenchTest.ino — bench test + calibration for the 3 arm servos, plus live telemetry.
// Serial Monitor at 115200, line ending "Newline". Commands:
//   s 1500   -> shoulder (GPIO18)     e 1500 -> elbow (GPIO19)     c 1500 -> claw (GPIO21)
// All servos start at 1500 us (centre).
// Limits: shoulder/elbow 850..2150 us (the arm's safe range in the rover firmware),
//         claw 700..2300 us. Move in 50-100 us steps when looking for mechanical ends.
//
// Telemetry: 20 times a second the board prints
//   T <shoulder_us> <elbow_us> <claw_us> <loop_max_us> <uptime_ms>
// The TakeOFF Arm Live page and the Arduino Serial Plotter both read this line.
#include <Arduino.h>

struct Ch { char key; uint8_t pin; uint8_t ch; const char *name; int minUs, maxUs; int us; };
Ch servos[] = {
  {'s', 18, 2, "shoulder", 850, 2150, 1500},
  {'e', 19, 4, "elbow",    850, 2150, 1500},
  {'c', 21, 6, "claw",     700, 2300, 1500},
};

void writeUs(Ch &s, int us, bool echo) {
  s.us = constrain(us, s.minUs, s.maxUs);
  uint32_t duty = (uint32_t)s.us * 65535UL / 20000UL;   // 50 Hz, 16-bit
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcWrite(s.pin, duty);
#else
  ledcWrite(s.ch, duty);
#endif
  if (echo) Serial.printf("%s -> %d us\n", s.name, s.us);
}

void setup() {
  Serial.begin(115200);
  Serial.setTimeout(20);
  for (auto &s : servos) {
#if ESP_ARDUINO_VERSION_MAJOR >= 3
    ledcAttach(s.pin, 50, 16);
#else
    ledcSetup(s.ch, 50, 16);
    ledcAttachPin(s.pin, s.ch);
#endif
    writeUs(s, 1500, true);
  }
  Serial.println("Ready: s/e/c <microseconds>");
}

String buf;

void handleLine(String line) {
  line.trim();
  if (line.length() < 3) return;
  bool quiet = line.endsWith("q");          // the live page adds 'q' to skip the echo
  for (auto &s : servos)
    if (line[0] == s.key) { writeUs(s, line.substring(1).toInt(), !quiet); return; }
  Serial.println("Use: s|e|c <us>");
}

void loop() {
  static uint32_t lastLoop = micros(), loopMax = 0, lastTel = 0;
  uint32_t nowUs = micros();
  uint32_t dtUs = nowUs - lastLoop;
  lastLoop = nowUs;
  if (dtUs > loopMax) loopMax = dtUs;

  while (Serial.available()) {               // non-blocking line reader
    char c = (char)Serial.read();
    if (c == '\n') { handleLine(buf); buf = ""; }
    else if (buf.length() < 40) buf += c;
  }

  uint32_t now = millis();
  if (now - lastTel >= 50) {
    lastTel = now;
    Serial.printf("T %d %d %d %lu %lu\n", servos[0].us, servos[1].us, servos[2].us,
                  (unsigned long)loopMax, (unsigned long)now);
    loopMax = 0;
  }
}
